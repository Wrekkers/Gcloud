package com.hudsondata.graph.utils;

import java.util.ArrayList;

public interface Reader {
	ArrayList<String> readSource();
}
